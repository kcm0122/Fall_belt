#ifndef __FALL_ALG_H
#define __FALL_ALG_H

#include "main.h"
#include "MPU6050.h"

typedef enum {
    STATE_NORMAL = 0,      //
	STATE_JUMP,
    STATE_FALL_CONFIRMED   // 
} FallState_t;

// time
#define IMPACT_MAX_TIME       3000  // 
#define STATIC_MAX_TIME       5000  // 
#define FALL_CONFIRMED_RESET_TIME 10000  // 
#define IMPACT_STATIC_DELAY 200 // 

void Fall_Detection_Init(void);
void Display_Fall_Status(GyroData_t *data);
void Trigger_Fall_Alarm(void);
FallState_t Get_Current_Fall_State(void);
void Reset_Fall_Detection(void);
float Calculate_Total_Acceleration(GyroData_t *gyro);
void Manual_alert(void);


#endif /* __FALL_ALG_H */
