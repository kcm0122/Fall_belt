#include "fall_alg.h"
#include "MPU6050.h"
#include "lcd.h"
#include <math.h>
#include <stdio.h>

static FallState_t current_fall_state = STATE_NORMAL;
uint32_t alarming;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;


FallState_t Detect_Fall_4_Stage(GyroData_t *data) {
    float total_accel = Calculate_Total_Acceleration(data);
    char status_msg[50];
    float test,test2,test3,test4,t5,t6,t7,t8,t9,t10;

    switch(current_fall_state) {
        case STATE_NORMAL: {
        	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5) == GPIO_PIN_RESET) {
        				Manual_alert();
        		        HAL_Delay(50);}


        	// front feature z compent dps is positive value and accel of z is negaitive


        	if(total_accel >= 1.85 && data->dps[2]>0 && data->accel[2] <-1.1) { // total_accel > a value will very big chance is falling, dps is checking the Z dps
                 test = total_accel; test2 = data->dps[0];
                 test3 = data->dps[1];
                 test4 = data->dps[2];
                 t5 = data->accel[0];
                 t6 = data->accel[1];
                 t7 = data->accel[2];
                 t8 =data->feature[7];
                 t9 =data->feature[8];
                t10 =data->feature[9];
                sprintf(status_msg,"TA %f ",test);
                LCD_DrawString(10, 220,status_msg );
                LCD_DrawString(10, 100, "front fall"  );

                sprintf(status_msg,"x dps %f ",test2);
                               LCD_DrawString(10, 100,status_msg );
                               sprintf(status_msg,"y dps %f ",test3);
                               LCD_DrawString(10, 120,status_msg );
                               sprintf(status_msg,"z dps %f ",test4);
                               LCD_DrawString(10, 140,status_msg );
                               sprintf(status_msg,"x a%f ",t5);
                               LCD_DrawString(80, 100,status_msg );
                               sprintf(status_msg,"y a%f ",t6);
                               LCD_DrawString(80, 120,status_msg );
                               sprintf(status_msg,"z a%f ",t7);
                               LCD_DrawString(80, 140,status_msg );
                               sprintf(status_msg,"angle 1 %f",t8);
                                             LCD_DrawString(10, 160,status_msg );
                                             sprintf(status_msg,"angle 2 %f",t9);
                                             LCD_DrawString(10, 180,status_msg );
                                             sprintf(status_msg,"angle 3 %f",t10);
                                             LCD_DrawString(10, 200,status_msg );

                return STATE_FALL_CONFIRMED;
            }
            else if(total_accel >= 1.85 && data->dps[2]<0 && data->accel[2]>1.1) {
            	// back feature z compent dps is negative value and accel of z is positive
                test = Calculate_Total_Acceleration(data);
                test2 = data->dps[0];
                test3 = data->dps[1];
                test4 = data->dps[2];
                t5 = data->accel[0];
                t6 = data->accel[1];
                 t7 = data->accel[2];
                 t8 =data->feature[7];
                 t9 =data->feature[8];
                 t10 =data->feature[9];
                 sprintf(status_msg,"TA %f ",test);
                 LCD_DrawString(10, 220,status_msg );
                  LCD_DrawString(10, 100, "back fall"  );

                 sprintf(status_msg,"x dps %f ",test2);
                 LCD_DrawString(10, 100,status_msg );
                 sprintf(status_msg,"y dps %f ",test3);
                 LCD_DrawString(10, 120,status_msg );
                 sprintf(status_msg,"z dps %f ",test4);
                 LCD_DrawString(10, 140,status_msg );
                 sprintf(status_msg,"x a%f ",t5);
                 LCD_DrawString(120, 100,status_msg );
                 sprintf(status_msg,"y a%f ",t6);
                 LCD_DrawString(120, 120,status_msg );
                 sprintf(status_msg,"z a%f ",t7);
                 LCD_DrawString(120, 140,status_msg );
                 sprintf(status_msg,"angle 1 %f",t8);
                 LCD_DrawString(10, 160,status_msg );
                 sprintf(status_msg,"angle 2 %f",t9);
                 LCD_DrawString(10, 180,status_msg );
                 sprintf(status_msg,"angle 3 %f",t10);
                 LCD_DrawString(10, 200,status_msg );

            return STATE_FALL_CONFIRMED;

            }else if(total_accel >= 1.85 && data->accel[1]<-1.4) {
            	 sprintf(status_msg,"you are jumping ");
            	 LCD_DrawString(80, 180,status_msg );
            	 return STATE_JUMP;
            	 break;

        }}

       case STATE_JUMP:
    	   if(total_accel <=1.1 ){
    		   return STATE_NORMAL;
    	   }
    	   break;

       case STATE_FALL_CONFIRMED:
           
            break;
    }

    return current_fall_state;
}

void Process_Fall_Detection(GyroData_t *data) {
    FallState_t state = Detect_Fall_4_Stage(data);

    if(state != current_fall_state) {//state is change
        if(state == STATE_FALL_CONFIRMED){Trigger_Fall_Alarm();}
        else if (state== STATE_JUMP){}
        else if (state == STATE_NORMAL){}
    }
}


void Display_Fall_Status(GyroData_t *data) {
    char status_msg[50];
    const char* state_names[] = {"Normal","JUMP", "FALL!"};
    float total_g = Calculate_Total_Acceleration(data);
    sprintf(status_msg, "State: %s       ", state_names[current_fall_state]);
    LCD_DrawString(0, 80, status_msg);
    sprintf(status_msg, "Accel: %.2fg  ", total_g);
    LCD_DrawString(120, 80, status_msg);
}


void Trigger_Fall_Alarm(void) {
	uint32_t start_time = HAL_GetTick();
	uint8_t button_pressed = 0,vibration_state = 0;
	uint32_t last_vibration_time = 0;

	while((HAL_GetTick() - start_time < 5000) && !button_pressed) {//5s
		uint32_t current_time = HAL_GetTick();
			//0.2 period
		    if(!vibration_state && (current_time - last_vibration_time >= 200)) {
		        HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
		        vibration_state = 1;
		        last_vibration_time = current_time;
		    }
		    else if(vibration_state && (current_time - last_vibration_time >= 200)) {// 停止振動
		        HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_3);
		        vibration_state = 0;
		        last_vibration_time = current_time;
		    }
		// if red is press
	    if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5) == GPIO_PIN_RESET) {
	        button_pressed = 1;  //break
	        HAL_Delay(50);
	    }
	}
	HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_3); //off the Vibration motor

	if(!button_pressed) {
	   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
	   LCD_DrawString(20, 250, "FALL DETECTED!");
	   LCD_DrawString(20, 290, "Need Assistance!");
	   HAL_Delay(100);
	   // RGB light
	   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
	   HAL_Delay(100);
	   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
	   HAL_Delay(100);

	   alarming=1; // alarm is ture
	   uint32_t buzzer_state = 0, last_buzzer_time = 0;

	    while(alarming==1) {  // leave until is press the red
	            uint32_t current_time = HAL_GetTick();

	             if(!buzzer_state && (current_time - last_buzzer_time >= 500)) {// 0.5 peried
	                 HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  //// Turn off the buzzer
	                 buzzer_state = 1;
	                 last_buzzer_time = current_time;
	             }
	             else if(buzzer_state && (current_time - last_buzzer_time >= 500)) {
	                 HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);   // buzzer
	                 buzzer_state = 0;
	                 last_buzzer_time = current_time;
	             }

	             HAL_Delay(10);
	         }

	         HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	         Reset_Fall_Detection();
	         HAL_Delay(50);

	} else {
		Reset_Fall_Detection();
		HAL_Delay(50);
	}

}


FallState_t Get_Current_Fall_State(void) {return current_fall_state;}

void Reset_Fall_Detection(void) {
    current_fall_state = STATE_NORMAL;
    alarming = 0;
    LCD_INIT();
}

float Calculate_Total_Acceleration(GyroData_t *gyro) {return sqrt(gyro->accel[0] * gyro->accel[0] + gyro->accel[1] * gyro->accel[1] +gyro->accel[2] * gyro->accel[2]);}



void Manual_alert(void) {

            // red bg
        LCD_Clear(0, 0, 240, 320, RED);
        LCD_DrawString(40, 20,  "User is unwell and");
        LCD_DrawString(40, 40,  "requesting urgent help.");
        LCD_DrawString(40, 60,  "Please provide immediate");
        LCD_DrawString(40, 80,  "assistance and check");
        LCD_DrawString(40, 100, "on my condition.");

        LCD_DrawString(10, 200, "Press Red Button to Cancel");
        Trigger_Fall_Alarm();


}
