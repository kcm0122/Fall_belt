#include "MPU6050.h"
#include "lcd.h"
#include <math.h>
#include "fall_alg.h"
extern I2C_HandleTypeDef hi2c2;

uint8_t MPU_6050_Write_Register(uint8_t reg, uint8_t data){// get only one reg
	return HAL_I2C_Mem_Write(&hi2c2, MPU6050_ADDR, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
}
//get mutiplr reg length 6 for all reg
uint8_t MPU6050_Read_Registers(uint8_t reg, uint8_t *data, uint8_t length){
    return HAL_I2C_Mem_Read(&hi2c2, MPU6050_ADDR, reg, I2C_MEMADD_SIZE_8BIT, data, length, 100);
}

void MPU6050_Gyro_Init(void){
	MPU_6050_Write_Register(0x6B, 0x80); // start the mpu6050
    HAL_Delay(100);
    MPU_6050_Write_Register(0x6B, 0x00); 
    HAL_Delay(100);

    MPU_6050_Write_Register(0x1B, 0x08); // FS_SEL = 1 (±500°/s)
    HAL_Delay(10);
    MPU6050_Write_Register(0x1C, 0x00);   // +- 2g
    HAL_Delay(10);
    MPU_6050_Write_Register(0x19, 0x04); // SMPLRT_DIV = 4  200Hz // sample rate
    HAL_Delay(10);

    MPU_6050_Write_Register(0x1A, 0x03); // DLPF_CFG = 3 (42Hz gyro ) // bandwidth(low pass)
    HAL_Delay(50);
}

// get MPU data
GyroData_t MPU6050_Read_DATA(void)
{
	GyroData_t gyro;
	uint8_t buffer[6];

    if (MPU6050_Read_Registers(0x43, buffer, 6) == HAL_OK) {
    	gyro.x = (int16_t)((buffer[0] << 8) | buffer[1]);
    	gyro.y = (int16_t)((buffer[2] << 8) | buffer[3]);
    	gyro.z = (int16_t)((buffer[4] << 8) | buffer[5]);
    }
    if (MPU6050_Read_Registers(0x3B, buffer, 6) == HAL_OK) {
        gyro.accel_x = (int16_t)((buffer[0] << 8) | buffer[1]);
        gyro.accel_y = (int16_t)((buffer[2] << 8) | buffer[3]);
        gyro.accel_z = (int16_t)((buffer[4] << 8) | buffer[5]);
    }

	return gyro;
}


void Convert_Gyro_To_DPS(GyroData_t *gyro, uint8_t fs_sel) {
    float sensitivity;

    switch(fs_sel) {
        case 0: sensitivity = 131.0f; break;  // ±250°/s
        case 1: sensitivity = 65.5f; break;   // ±500°/s
        case 2: sensitivity = 32.8f; break;   // ±1000°/s
        case 3: sensitivity = 16.4f; break;   // ±2000°/s
        default: sensitivity = 65.5f;
    }

    gyro->dps[0] = gyro->x / sensitivity;
    gyro->dps[1] = gyro->y / sensitivity;
    gyro->dps[2] = gyro->z / sensitivity;
}

void Convert_Accel_To_G(GyroData_t *gyro, uint8_t afs_sel) {
    float sensitivity;

    switch(afs_sel) {
        case 0: sensitivity = 16384.0f; break;  // ±2g
        case 1: sensitivity = 8192.0f; break;   // ±4g
        case 2: sensitivity = 4096.0f; break;   // ±8g
        case 3: sensitivity = 2048.0f; break;   // ±16g
        default: sensitivity = 8192.0f;
    }

    gyro->accel[0] = gyro->accel_x / sensitivity;
    gyro->accel[1] = gyro->accel_y / sensitivity;
    gyro->accel[2] = gyro->accel_z / sensitivity;
}

void Extract_Features(GyroData_t *data) {
    // 1. acceleration
    data->feature[0] = Calculate_Total_Acceleration(data);  // 總加速度
    data->feature[1] = data->accel[0]; // x
    data->feature[2] = data->accel[1];//y
    data->feature[3] = data->accel[2];//z

    // 2. dps
    data->feature[4] = data->dps[0];  // x
    data->feature[5] = data->dps[1];  // y
    data->feature[6] = data->dps[2];  // z

    // 3. angle
    data->feature[7] = atan2(data->accel[1], data->accel[0]) * 180/3.14159; // 水平方向角
    data->feature[8] =atan2(-data->accel[0],  sqrt(data->accel[1]*data->accel[1] + data->accel[2]*data->accel[2])) * 180/3.14159;
    data->feature[9] = atan2(data->accel[2], sqrt(data->accel[0]*data->accel[0] + data->accel[1]*data->accel[1])) * 180/3.14159; // 俯仰角
}

void Display_Data(GyroData_t *gyro, uint8_t display_raw)
{
    char display_str[30];
     
        sprintf(display_str, "%6.1f", gyro->dps[0]);
        LCD_DrawString(0, 32, display_str);
        sprintf(display_str, "%6.1f", gyro->dps[1]);
        LCD_DrawString(0, 48, display_str);
        sprintf(display_str, "%6.1f", gyro->dps[2]);
        LCD_DrawString(0, 64, display_str);

        sprintf(display_str, "%6.2f", gyro->accel[0]);
        LCD_DrawString(75, 32, display_str);
        sprintf(display_str, "%6.2f", gyro->accel[1]);
        LCD_DrawString(75, 48, display_str);
        sprintf(display_str, "%6.2f", gyro->accel[2]);
        LCD_DrawString(75, 64, display_str);

        sprintf(display_str, "%6.2f", gyro->feature[7]);
         LCD_DrawString(150, 32, display_str);
        sprintf(display_str, "%6.2f", gyro->feature[8]);
         LCD_DrawString(150, 48, display_str);
          sprintf(display_str, "%6.2f", gyro->feature[9]);
         LCD_DrawString(150, 64, display_str);

}

